var express = require('express');
var router = express.Router();
var axios = require('axios');



var {
    access_Token,
} = require('./auth');

var fetch = require('../fetch');

var { GRAPH_ME_ENDPOINT,userId } = require('../authConfig');

// custom middleware to check auth state
function isAuthenticated(req, res, next) {
    if (!req.session.isAuthenticated) {
        return res.redirect('/auth/signin'); // redirect to sign-in route
    }

    next();
};

router.get('/id',
    isAuthenticated, // check if user is authenticated
    async function (req, res, next) {
        res.render('id', { idTokenClaims: req.session.account.idTokenClaims });
    }
);

// router.get('/messages',
//  // check if user is authenticated
//  function (req, res, next) {
//     res.send('Hello world');
    
// }
// ); 

router.get('/messages/:id',
isAuthenticated, // check if user is authenticated
async function (req, res, next) {
    const id= req.params.id;
    console.log("===id===",id);
    try {
        let graphResponse = await fetch(`https://graph.microsoft.com/beta/teams/6b1b1e3b-f183-4c7d-ae19-b05bfe90c27a/channels/${id}/messages`, req.session.accessToken);
       // await fetch(`https://graph.microsoft.com/v1.0/teams/6b1b1e3b-f183-4c7d-ae19-b05bfe90c27a/allChannels/allChannels/${id}/messages`, req.session.accessToken);
        https://graph.microsoft.com/beta/teams/02bd9fd6-8f93-4758-87c3-1fb73740a315/channels/19:d0bba23c2fc8413991125a43a54cc30e@thread.skype/messages
       /* graphResponse.value.forEach(element => {
            console.log("---graphResponse.id"+element.id); https://graph.microsoft.com/v1.0/groups
            https://graph.microsoft.com/v1.0/teams/6b1b1e3b-f183-4c7d-ae19-b05bfe90c27a/allChannels - fetching channel by team id
            console.log("graphResponse.description"+element.description);
            console.log("graphResponse.displayName	"+element.displayName	);
        }); */
        //console.log("---graphResponse---"+graphResponse);
        graphResponse = graphResponse.value.filter(isValid);

        function isValid(obj) {
            if(obj.body.contentType ==='text')
            return true
          return false
        }
        res.render('chats', { channels: graphResponse});
        console.log(" --res-- ",graphResponse)
    } catch (error) {
        next(error);
    }
}
); 


router.get('/members/:id',
isAuthenticated, // check if user is authenticated
async function (req, res, next) {
    const id= req.params.id;
    console.log("===id===",id);
    try {
        const graphResponse = await fetch(`https://graph.microsoft.com/v1.0/teams/${id}/members`, req.session.accessToken);
       /* graphResponse.value.forEach(element => {
            console.log("---graphResponse.id"+element.id); https://graph.microsoft.com/v1.0/groups
            https://graph.microsoft.com/v1.0/teams/6b1b1e3b-f183-4c7d-ae19-b05bfe90c27a/allChannels - fetching channel by team id
            console.log("graphResponse.description"+element.description);
            console.log("graphResponse.displayName	"+element.displayName	);
        }); */
        //console.log("---graphResponse---"+graphResponse);

        res.render('members', { members: graphResponse.value});
        console.log(" --res-- ",res)
    } catch (error) {
        next(error);
    }
}
); 

router.get('/teams',
//isAuthenticated, // check if user is authenticated
async function (req, res, next) {
    try {
        const graphResponse = await fetch('https://graph.microsoft.com/v1.0/groups', req.session.accessToken);
       /* graphResponse.value.forEach(element => {
            console.log("---graphResponse.id"+element.id); https://graph.microsoft.com/v1.0/groups
            https://graph.microsoft.com/v1.0/teams/6b1b1e3b-f183-4c7d-ae19-b05bfe90c27a/allChannels - fetching channel by team id
            console.log("graphResponse.description"+element.description);
            console.log("graphResponse.displayName	"+element.displayName	);
        }); */
        //console.log("---graphResponse---"+graphResponse);

        res.render('teams', { teams: graphResponse.value});
        //res.send(graphResponse);
        console.log(" --res-- ",res)
    } catch (error) {
        next(error);
    }
}
); 

router.get('/channels/:id',
isAuthenticated, // check if user is authenticated
async function (req, res, next) {
    const id= req.params.id;
    console.log("===id===",id);
    try {
        const graphResponse = await fetch(`https://graph.microsoft.com/v1.0/teams/${id}/allChannels`, req.session.accessToken);
       /* graphResponse.value.forEach(element => {
            console.log("---graphResponse.id"+element.id); https://graph.microsoft.com/v1.0/groups
            https://graph.microsoft.com/v1.0/teams/6b1b1e3b-f183-4c7d-ae19-b05bfe90c27a/allChannels - fetching channel by team id
            console.log("graphResponse.description"+element.description);
            console.log("graphResponse.displayName	"+element.displayName	);
        }); */
        //console.log("---graphResponse---"+graphResponse);

        res.render('channels', { channels: graphResponse.value});
        console.log(" --res-- ",res)
    } catch (error) {
        next(error);
    }
}
); 
/*
  router.get('/profile',isAuthenticated,
   // check if user is authenticated
  async function (req, res, next) {
      try {
          const graphResponse = await fetch('https://graph.microsoft.com/v1.0/me', access_Token);
          console.log(graphResponse);
          /*graphResponse.value.forEach(element => {
            console.log(element.bodyPreview);
            
          }); 
          //res.send(200, stringify(graphResponse));
      } catch (error) {
          next(error);
      }
  }
);*/


module.exports = router;
